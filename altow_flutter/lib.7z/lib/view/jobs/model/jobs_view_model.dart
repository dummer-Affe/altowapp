import 'package:mobx/mobx.dart';
part 'jobs_view_model.g.dart';

class JobsViewModel = _JobsViewModelBase with _$JobsViewModel;

abstract class _JobsViewModelBase with Store {
  
}