import 'package:mobx/mobx.dart';
part 'altow_academy_view_model.g.dart';

class AltowAcademyViewModel = _AltowAcademyViewModelBase with _$AltowAcademyViewModel;

abstract class _AltowAcademyViewModelBase with Store {
  
}