import 'package:mobx/mobx.dart';
part 'ueber_uns_view_model.g.dart';

class UeberUnsViewModel = _UeberUnsViewModelBase with _$UeberUnsViewModel;

abstract class _UeberUnsViewModelBase with Store {
  
}