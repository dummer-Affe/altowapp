import 'package:mobx/mobx.dart';

part 'home_base_view_model.g.dart';

class HomeBaseViewModel = _HomeBaseViewModelBase with _$HomeBaseViewModel;

abstract class _HomeBaseViewModelBase with Store {}
