// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'otp_checker_parameter.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OtpCheckerParameter _$OtpCheckerParameterFromJson(Map<String, dynamic> json) =>
    OtpCheckerParameter(
      mobilePhone: json['mobilePhone'] as String?,
      email: json['email'] as String?,
    );

Map<String, dynamic> _$OtpCheckerParameterToJson(
        OtpCheckerParameter instance) =>
    <String, dynamic>{
      'mobilePhone': instance.mobilePhone,
      'email': instance.email,
    };
