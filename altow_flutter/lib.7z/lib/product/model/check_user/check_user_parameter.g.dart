// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'check_user_parameter.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CheckUserParameter _$CheckUserParameterFromJson(Map<String, dynamic> json) =>
    CheckUserParameter(
      phoneNumber: json['phoneNumber'] as String?,
    );

Map<String, dynamic> _$CheckUserParameterToJson(CheckUserParameter instance) =>
    <String, dynamic>{
      'phoneNumber': instance.phoneNumber,
    };
