// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'login_parameter.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

LoginParameter _$LoginParameterFromJson(Map<String, dynamic> json) =>
    LoginParameter(
      username: json['username'] as String?,
      password: json['password'] as String?,
    );

Map<String, dynamic> _$LoginParameterToJson(LoginParameter instance) =>
    <String, dynamic>{
      'username': instance.username,
      'password': instance.password,
    };
