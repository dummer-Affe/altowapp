class JobsPageText {
  static String title = "Jobs bei altow";
  static String paragraph =
      "Bei Altow zählt der Kopf, nicht der Kleidungsstil. Ideen haben bei uns einen Wert, Einsatz wird honoriert. Wir fördern unsere persönliche & fachliche Weiterentwicklung, eingebettet in ein teamorientiertes & kooperatives Arbeitsumfeld.";
  static String paragraph_2 =
      "Agiles Arbeiten ist seit Jahren ein gelebter Bestandteil unserer Unternehmenskultur. Bei uns kannst du dich von der ersten Minute an einbringen und Verantwortung übernehmen. Wir leben den Ansatz “als Team kompetent, als Individuum stark”.";

  static String paragraph_3 =
      "Eine gute Work-Life-Balance ist uns wichtig. Verschiedene Teilzeitmodelle und auch ein Sabbatical sind möglich. Am Ende lässt sich alles reduzieren: Meld´ dich bei uns und überzeug´ dich selbst von uns bei einem persönlichen Kennenlernen!";
}
