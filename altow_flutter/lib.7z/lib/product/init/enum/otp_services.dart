enum OtpPathEnum {
  checkUserNecessarySendOtp,
  checkOtp,
  resendOtp,
}
