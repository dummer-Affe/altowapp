enum ServiceStatus { onProcess, failed, success, waiting }
