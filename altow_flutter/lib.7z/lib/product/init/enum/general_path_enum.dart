enum GeneralPathEnum { register, renewPassword, login, checkUser }
