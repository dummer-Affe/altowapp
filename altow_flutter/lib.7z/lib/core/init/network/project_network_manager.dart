import 'network_config.dart';

class ProjectNetworkManager {
  static NetworkConfig get config => NetworkConfig();
}
