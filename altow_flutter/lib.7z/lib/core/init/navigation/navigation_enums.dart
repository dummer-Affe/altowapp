enum NavigationEnums {
  login,
  mobilePhoneNumberLogin,
  registerEmail,
  dateOfBirth,
  setPassword,
  otp,
  loginPassword,
  storyDetail,
  homebase,
  splash,
  webviewPage
}
